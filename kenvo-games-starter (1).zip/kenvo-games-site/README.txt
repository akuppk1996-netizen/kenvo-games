KENVO GAMES — STARTER WEBSITE
============================

WHAT IS INCLUDED
- index.html: responsive black/red Kenvo Games website.
- Search bar and genre filters work.
- Cards for KENVO BATTLE and KENVO ROAD: DON'T STOP.
- Placeholder cards do NOT pretend the actual games are already playable.

IMPORTANT: GAME FILES ARE NOT INCLUDED YET
The starter site has not integrated the original game builds. The website can only launch a game once you add its actual HTML build and supporting files.

WHERE TO PUT GAME BUILDS
1) KENVO BATTLE: put the game's main HTML file and all its assets in games/kenvo-battle/.
2) KENVO ROAD: DON'T STOP: put its main HTML file and all its assets in games/kenvo-road/.
3) Tell your developer/assistant which file is the main entry point (usually index.html) so the cards can be connected to it.
4) Test each game in a desktop browser and on mobile before publishing.

PUBLISH FREE WITH GITHUB PAGES
1) Create/sign in to a GitHub account at https://github.com/
2) Create a public repository named kenvo-games (or another unique name).
3) Upload the CONTENTS of this folder (index.html, README.txt, and games folder) to the repository root.
4) Open repository Settings > Pages.
5) Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6) Wait for GitHub Pages to publish. The address will look like https://YOUR-USERNAME.github.io/kenvo-games/ .
7) Open the address and test search, filters, and each game link.

GOOGLE SEARCH
- Add the published site in Google Search Console: https://search.google.com/search-console/
- Verify ownership and submit the sitemap when one is added; request indexing for the homepage.
- Search visibility is not instant or guaranteed. Use the exact brand consistently and link to the site from your social profiles.

NOTES
- GitHub Pages hosts static websites; it does not run server-side code.
- Check third-party libraries, images, music, and logos for permission before publishing.
- A custom domain is optional and usually costs money.
